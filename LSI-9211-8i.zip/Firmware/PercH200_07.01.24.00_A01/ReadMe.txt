*******************************************************************************
** This release package contains the files necessary to flash the Dell
** H200A Adapter with:
**     Package version -------------- 07.01.24.00
**     Firmware Version ------------- 02.15.59.00
**     Option BIOS Version ---------- 7.01.08.00-Dellized_15
**     Boot services Driver Version - 2.00.01.09
**     NVDATA Version --------------- Version 14
**


To flash, boot to a DOS environment and execute the included batch file from 
the Command line as:

     <path>:\flash.bat

     Where <path> is the path to the folder containing the contents of the release
     package.
