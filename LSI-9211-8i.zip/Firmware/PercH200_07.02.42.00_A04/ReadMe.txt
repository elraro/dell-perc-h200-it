*******************************************************************************
** This release package contains the files necessary to flash the Dell
** H200A Adapter with:
**     Package version -------------- 07.02.42.00
**     Firmware Version ------------- 07.15.04.00
**     Option BIOS Version ---------- 7.11.01.00-Dellized_19
**     Boot services Driver Version - 7.00.01.00
**     NVDATA Version --------------- Version 17
**


To flash, boot to a DOS environment and execute the included batch file from 
the Command line as:

     <path>:\flash.bat

     Where <path> is the path to the folder containing the contents of the release
     package.
